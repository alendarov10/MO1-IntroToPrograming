using System;
//Ctrl+K+D
public class Program
{
	public static void Main()
	{
		Console.Write("Hello, World!");
	}
}