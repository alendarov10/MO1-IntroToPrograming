﻿using System;

using System;
public class Program
{
    public static void Main()
    {
        Console.Write("a = ");
        int a = int.Parse(Console.ReadLine());
        int s = a * a;
        Console.WriteLine($"Area = {s}");
    }
}
