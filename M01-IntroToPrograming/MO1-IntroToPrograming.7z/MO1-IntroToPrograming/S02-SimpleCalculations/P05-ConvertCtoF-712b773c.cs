﻿using System;

public class Program
{
    public static void Main()
    {
        double c = double.Parse(Console.ReadLine());
        double f = c * 9.0 / 5.0 + 32;

        Console.WriteLine(f);
    }
}